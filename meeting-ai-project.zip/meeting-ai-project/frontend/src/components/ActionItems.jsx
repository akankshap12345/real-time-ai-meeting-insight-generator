// ActionItems.jsx
import { useState } from 'react';

export default function ActionItems({ items = [], keyPoints = [] }) {
  const [checked, setChecked] = useState({});

  const toggle = (i) => setChecked((prev) => ({ ...prev, [i]: !prev[i] }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Key Points */}
      <div className="glass-card p-5">
        <h3 className="font-display font-semibold text-white text-sm flex items-center gap-2 mb-4">
          <span>💡</span> Key Discussion Points
        </h3>
        {keyPoints.length === 0 ? (
          <p className="text-blue-400/40 text-sm">No key points generated yet.</p>
        ) : (
          <ul className="space-y-2.5">
            {keyPoints.map((point, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs text-blue-400 font-mono font-bold">{i + 1}</span>
                </div>
                <span className="text-sm text-blue-100/80 font-body leading-relaxed">{point}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Action Items */}
      <div className="glass-card p-5">
        <h3 className="font-display font-semibold text-white text-sm flex items-center gap-2 mb-4">
          <span>✅</span> Action Items
          {items.length > 0 && (
            <span className="ml-auto text-xs font-mono text-blue-400/40">
              {Object.values(checked).filter(Boolean).length}/{items.length} done
            </span>
          )}
        </h3>
        {items.length === 0 ? (
          <p className="text-blue-400/40 text-sm">No action items identified yet.</p>
        ) : (
          <ul className="space-y-2.5">
            {items.map((item, i) => (
              <li
                key={i}
                className="flex items-start gap-2.5 cursor-pointer group"
                onClick={() => toggle(i)}
              >
                <div className={`w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 mt-0.5 transition-all
                  ${checked[i]
                    ? 'bg-emerald-500/30 border-emerald-500/50'
                    : 'border-blue-400/20 group-hover:border-blue-400/40'}`}
                >
                  {checked[i] && <span className="text-emerald-400 text-xs">✓</span>}
                </div>
                <span className={`text-sm font-body leading-relaxed transition-all ${checked[i] ? 'line-through text-blue-400/30' : 'text-blue-100/80'}`}>
                  {item}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
