// LiveTranscript.jsx
import { useEffect, useRef } from 'react';

const SPEAKER_COLORS = {
  'Speaker': 'text-blue-400',
  'Alex': 'text-cyan-400',
  'Sarah': 'text-emerald-400',
  'Mike': 'text-yellow-400',
  'Unknown': 'text-purple-400',
};

function getSpeakerColor(speaker) {
  return SPEAKER_COLORS[speaker] || 'text-blue-300';
}

function getSpeakerInitial(speaker) {
  return (speaker || 'S').charAt(0).toUpperCase();
}

function formatTime(timestamp) {
  if (!timestamp) return '';
  try {
    const date = new Date(timestamp);
    if (isNaN(date)) return timestamp.slice(0, 8);
    return date.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    return '';
  }
}

export default function LiveTranscript({ transcripts = [], isLive = false }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcripts]);

  return (
    <div className="glass-card p-5 h-80 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-shrink-0">
        <h3 className="font-display font-semibold text-white text-sm flex items-center gap-2">
          <span>📝</span> Live Transcript
        </h3>
        <div className="flex items-center gap-2">
          {isLive && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20">
              <div className="record-dot w-2 h-2" />
              <span className="text-xs text-red-400 font-display font-semibold">LIVE</span>
            </div>
          )}
          <span className="text-xs text-blue-400/40 font-mono">{transcripts.length} segments</span>
        </div>
      </div>

      {/* Transcript body */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-3">
        {transcripts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="text-4xl mb-3 opacity-20">🎙️</div>
            <p className="text-blue-400/40 text-sm font-body">
              {isLive ? 'Listening for speech...' : 'No transcript yet. Start a meeting to begin.'}
            </p>
          </div>
        ) : (
          transcripts.map((t, i) => (
            <div key={t.transcript_id || i} className="transcript-line">
              <div className="flex items-start gap-2.5">
                {/* Speaker avatar */}
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5
                  ${t.speaker === 'Alex' ? 'bg-cyan-500/20 text-cyan-400' :
                    t.speaker === 'Sarah' ? 'bg-emerald-500/20 text-emerald-400' :
                    t.speaker === 'Mike' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-blue-500/20 text-blue-400'}`}
                >
                  {getSpeakerInitial(t.speaker)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className={`text-xs font-display font-semibold ${getSpeakerColor(t.speaker)}`}>
                      {t.speaker || 'Speaker'}
                    </span>
                    <span className="text-xs text-blue-400/30 font-mono">{formatTime(t.timestamp)}</span>
                    {t.confidence && (
                      <span className="text-xs text-blue-400/20 font-mono">
                        {Math.round((t.confidence || 0) * 100)}%
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-blue-100/80 font-body leading-relaxed">{t.text}</p>
                </div>
              </div>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
