// MeetingHistory.jsx
import { useState } from 'react';

function formatDuration(seconds) {
  if (!seconds) return '—';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  try {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
    });
  } catch { return dateStr; }
}

export default function MeetingHistory({ meetings = [], onSelect }) {
  const [expanded, setExpanded] = useState(null);

  return (
    <div className="glass-card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-white text-sm flex items-center gap-2">
          <span>📅</span> Meeting History
        </h3>
        <span className="text-xs text-blue-400/40 font-mono">{meetings.length} meetings</span>
      </div>

      {meetings.length === 0 ? (
        <div className="text-center py-10">
          <div className="text-4xl mb-3 opacity-20">📋</div>
          <p className="text-blue-400/40 text-sm">No meetings recorded yet.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left text-xs text-blue-400/40 font-mono uppercase tracking-wider pb-2 pr-4">Title</th>
                <th className="text-left text-xs text-blue-400/40 font-mono uppercase tracking-wider pb-2 pr-4">Date</th>
                <th className="text-left text-xs text-blue-400/40 font-mono uppercase tracking-wider pb-2 pr-4">Duration</th>
                <th className="text-left text-xs text-blue-400/40 font-mono uppercase tracking-wider pb-2 pr-4">Participants</th>
                <th className="text-left text-xs text-blue-400/40 font-mono uppercase tracking-wider pb-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {meetings.map((m) => (
                <>
                  <tr
                    key={m.meeting_id}
                    className="border-b border-white/3 hover:bg-white/3 cursor-pointer transition-colors"
                    onClick={() => {
                      setExpanded(expanded === m.meeting_id ? null : m.meeting_id);
                      onSelect?.(m);
                    }}
                  >
                    <td className="py-3 pr-4 font-display font-medium text-white">{m.title}</td>
                    <td className="py-3 pr-4 text-blue-300/60 font-body">{formatDate(m.date)}</td>
                    <td className="py-3 pr-4 text-blue-300/60 font-mono text-xs">{formatDuration(m.duration)}</td>
                    <td className="py-3 pr-4">
                      <span className="text-blue-300/60 font-body">{m.participant_count || 1}</span>
                    </td>
                    <td className="py-3">
                      <span className={`status-badge ${m.status === 'active' ? 'status-active' : 'status-completed'}`}>
                        {m.status}
                      </span>
                    </td>
                  </tr>
                  {expanded === m.meeting_id && m.summary && (
                    <tr key={`${m.meeting_id}-expanded`} className="bg-blue-500/5">
                      <td colSpan={5} className="px-4 py-3">
                        <p className="text-xs text-blue-300/60 font-body leading-relaxed">
                          <span className="text-blue-400/60 font-mono mr-2">SUMMARY:</span>
                          {m.summary}
                        </p>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
