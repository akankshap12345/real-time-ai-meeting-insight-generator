// Sidebar.jsx
import { useNavigate, useLocation } from 'react-router-dom';

const NAV_ITEMS = [
  { icon: '🏠', label: 'Overview', path: '/dashboard' },
  { icon: '🎙️', label: 'Start Meeting', path: '/meeting' },
  { icon: '📋', label: 'History', path: '/history' },
  { icon: '🏠', label: 'Landing Page', path: '/' },
];

export default function Sidebar({ isMeetingActive }) {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <aside className="sidebar w-56 min-h-screen flex flex-col pt-5 pb-6 px-3 z-20 relative">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-3 mb-8">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-base shadow-lg">
          🧠
        </div>
        <div>
          <div className="font-display font-bold text-sm text-white">MeetingAI</div>
          <div className="text-xs text-blue-400/50">v1.0</div>
        </div>
      </div>

      {/* Active meeting indicator */}
      {isMeetingActive && (
        <div className="mx-1 mb-4 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center gap-2">
          <div className="record-dot" />
          <span className="text-xs text-red-400 font-display font-semibold">Recording Live</span>
        </div>
      )}

      {/* Nav */}
      <nav className="flex flex-col gap-1 flex-1">
        <p className="px-3 text-xs text-blue-400/30 font-mono uppercase tracking-widest mb-2">Navigation</p>
        {NAV_ITEMS.map((item) => (
          <div
            key={item.path}
            className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
            onClick={() => navigate(item.path)}
          >
            <span>{item.icon}</span>
            <span>{item.label}</span>
          </div>
        ))}
      </nav>

      {/* Bottom */}
      <div className="mt-auto">
        <div className="glass-card p-3 text-center">
          <p className="text-xs text-blue-400/40 font-mono">AI Project</p>
          <p className="text-xs text-blue-300/60 font-body mt-1">Whisper + T5 NLP</p>
        </div>
      </div>
    </aside>
  );
}
