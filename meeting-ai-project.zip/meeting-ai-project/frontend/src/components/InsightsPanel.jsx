// InsightsPanel.jsx
export default function InsightsPanel({ insights }) {
  if (!insights) {
    return (
      <div className="glass-card p-5 h-80 flex flex-col items-center justify-center">
        <div className="text-4xl mb-3 opacity-20">🧠</div>
        <p className="text-blue-400/40 text-sm text-center">
          AI insights will appear here once the meeting has sufficient transcript data.
        </p>
      </div>
    );
  }

  const SENTIMENT_CONFIG = {
    positive: { icon: '😊', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20' },
    negative: { icon: '😟', color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20' },
    neutral: { icon: '😐', color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20' },
  };
  const sentiment = SENTIMENT_CONFIG[insights.sentiment] || SENTIMENT_CONFIG.neutral;

  return (
    <div className="glass-card p-5 h-80 flex flex-col">
      <div className="flex items-center justify-between mb-3 flex-shrink-0">
        <h3 className="font-display font-semibold text-white text-sm flex items-center gap-2">
          <span>🧠</span> AI Insights
        </h3>
        <div className={`px-2.5 py-1 rounded-full text-xs font-display font-semibold border ${sentiment.bg} ${sentiment.color}`}>
          {sentiment.icon} {insights.sentiment}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 pr-1">
        {/* Summary */}
        {insights.summary && (
          <div>
            <p className="text-xs text-blue-400/50 font-mono uppercase tracking-wider mb-1.5">Summary</p>
            <p className="text-sm text-blue-100/80 font-body leading-relaxed">{insights.summary}</p>
          </div>
        )}

        {/* Keywords */}
        {insights.keywords?.length > 0 && (
          <div>
            <p className="text-xs text-blue-400/50 font-mono uppercase tracking-wider mb-1.5">Keywords</p>
            <div className="flex flex-wrap">
              {insights.keywords.map((kw, i) => (
                <span key={i} className="keyword-tag">{kw}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
