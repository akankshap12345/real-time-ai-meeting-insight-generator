// SpeakerChart.jsx
import { useEffect, useRef } from 'react';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
} from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

const SPEAKER_COLORS = [
  'rgba(99, 128, 232, 0.8)',
  'rgba(34, 211, 238, 0.8)',
  'rgba(52, 211, 153, 0.8)',
  'rgba(251, 191, 36, 0.8)',
  'rgba(248, 113, 113, 0.8)',
];

export function SpeakerPieChart({ transcripts = [] }) {
  // Aggregate speaking time by speaker
  const speakerData = {};
  transcripts.forEach((t) => {
    const sp = t.speaker || 'Unknown';
    speakerData[sp] = (speakerData[sp] || 0) + t.text.split(' ').length;
  });

  const speakers = Object.keys(speakerData);
  const values = Object.values(speakerData);

  const data = {
    labels: speakers.length ? speakers : ['No Data'],
    datasets: [
      {
        data: values.length ? values : [1],
        backgroundColor: SPEAKER_COLORS.slice(0, Math.max(speakers.length, 1)),
        borderColor: SPEAKER_COLORS.slice(0, Math.max(speakers.length, 1)).map((c) =>
          c.replace('0.8', '1')
        ),
        borderWidth: 2,
        hoverOffset: 8,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: 'rgba(232, 238, 255, 0.7)',
          font: { family: 'DM Sans', size: 12 },
          padding: 12,
          boxWidth: 12,
          boxHeight: 12,
        },
      },
      tooltip: {
        callbacks: {
          label: (ctx) => ` ${ctx.label}: ${ctx.raw} words`,
        },
        backgroundColor: 'rgba(7, 9, 61, 0.9)',
        titleColor: '#e8eeff',
        bodyColor: 'rgba(232, 238, 255, 0.7)',
        borderColor: 'rgba(99, 128, 232, 0.3)',
        borderWidth: 1,
      },
    },
  };

  return (
    <div className="glass-card p-5 h-72">
      <h3 className="font-display font-semibold text-white text-sm mb-3 flex items-center gap-2">
        <span>🎤</span> Speaker Distribution
      </h3>
      <div className="h-52">
        <Doughnut data={data} options={options} />
      </div>
    </div>
  );
}

export function TimelineChart({ transcripts = [] }) {
  // Group transcripts by time buckets (every 5 minutes)
  const buckets = {};
  transcripts.forEach((t, i) => {
    const bucket = `Seg ${Math.floor(i / 3) + 1}`;
    buckets[bucket] = (buckets[bucket] || 0) + 1;
  });

  const labels = Object.keys(buckets).slice(-8);
  const values = Object.values(buckets).slice(-8);

  const data = {
    labels: labels.length ? labels : ['No data'],
    datasets: [
      {
        label: 'Transcript Segments',
        data: values.length ? values : [0],
        backgroundColor: 'rgba(99, 128, 232, 0.5)',
        borderColor: 'rgba(99, 128, 232, 0.9)',
        borderWidth: 2,
        borderRadius: 6,
        borderSkipped: false,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: 'rgba(7, 9, 61, 0.9)',
        titleColor: '#e8eeff',
        bodyColor: 'rgba(232, 238, 255, 0.7)',
        borderColor: 'rgba(99, 128, 232, 0.3)',
        borderWidth: 1,
      },
    },
    scales: {
      x: {
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: { color: 'rgba(232,238,255,0.4)', font: { family: 'DM Sans', size: 11 } },
      },
      y: {
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: { color: 'rgba(232,238,255,0.4)', font: { family: 'DM Sans', size: 11 } },
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="glass-card p-5 h-72">
      <h3 className="font-display font-semibold text-white text-sm mb-3 flex items-center gap-2">
        <span>📈</span> Conversation Timeline
      </h3>
      <div className="h-52">
        <Bar data={data} options={options} />
      </div>
    </div>
  );
}
