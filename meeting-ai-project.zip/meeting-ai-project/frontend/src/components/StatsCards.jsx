// StatsCards.jsx
import { useState, useEffect } from 'react';
import { getDashboardStats, MOCK_STATS } from '../api';

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

const CARD_CONFIGS = [
  {
    key: 'total_meetings',
    label: 'Total Meetings',
    icon: '📅',
    color: 'from-blue-600 to-indigo-600',
    glow: 'rgba(99, 128, 232, 0.3)',
    format: (v) => v,
    suffix: '',
  },
  {
    key: 'total_duration_seconds',
    label: 'Total Duration',
    icon: '⏱️',
    color: 'from-cyan-600 to-teal-600',
    glow: 'rgba(34, 211, 238, 0.2)',
    format: formatDuration,
    suffix: '',
  },
  {
    key: 'total_transcripts',
    label: 'Transcript Segments',
    icon: '📝',
    color: 'from-violet-600 to-purple-600',
    glow: 'rgba(139, 92, 246, 0.2)',
    format: (v) => v,
    suffix: '',
  },
  {
    key: 'total_insights',
    label: 'AI Insights Generated',
    icon: '🧠',
    color: 'from-emerald-600 to-green-600',
    glow: 'rgba(52, 211, 153, 0.2)',
    format: (v) => v,
    suffix: '',
  },
];

export default function StatsCards() {
  const [stats, setStats] = useState(MOCK_STATS);

  useEffect(() => {
    getDashboardStats()
      .then((res) => setStats(res.stats || MOCK_STATS))
      .catch(() => setStats(MOCK_STATS));
  }, []);

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {CARD_CONFIGS.map((card, i) => (
        <div
          key={card.key}
          className="glass-card p-5 relative overflow-hidden"
          style={{ animationDelay: `${i * 0.1}s` }}
        >
          {/* BG gradient accent */}
          <div
            className={`absolute top-0 right-0 w-20 h-20 rounded-full bg-gradient-to-br ${card.color} opacity-10 -translate-y-6 translate-x-6`}
          />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xl">{card.icon}</span>
              <div className={`w-2 h-2 rounded-full bg-gradient-to-br ${card.color} opacity-80`} />
            </div>
            <div className="font-display font-bold text-2xl text-white stat-value">
              {card.format(stats[card.key] || 0)}{card.suffix}
            </div>
            <div className="text-xs text-blue-300/50 mt-1 font-body">{card.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
