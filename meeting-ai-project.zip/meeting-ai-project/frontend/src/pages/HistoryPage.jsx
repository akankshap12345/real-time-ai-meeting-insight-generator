// HistoryPage.jsx
import { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import MeetingHistory from '../components/MeetingHistory';
import { getMeetingHistory, getMeeting, MOCK_HISTORY, MOCK_TRANSCRIPTS, MOCK_INSIGHTS } from '../api';
import LiveTranscript from '../components/LiveTranscript';
import ActionItems from '../components/ActionItems';

export default function HistoryPage() {
  const [meetings, setMeetings] = useState(MOCK_HISTORY);
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getMeetingHistory()
      .then((r) => setMeetings(r.meetings || MOCK_HISTORY))
      .catch(() => setMeetings(MOCK_HISTORY));
  }, []);

  const handleSelect = async (meeting) => {
    setSelected(meeting);
    setLoading(true);
    try {
      const res = await getMeeting(meeting.meeting_id);
      setDetail(res);
    } catch {
      setDetail({ transcripts: MOCK_TRANSCRIPTS, insights: MOCK_INSIGHTS });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen hero-bg noise-overlay">
      <div className="absolute inset-0 grid-pattern opacity-20 pointer-events-none" />
      <Sidebar />
      <main className="flex-1 p-6 overflow-y-auto relative z-10">
        <div className="mb-6">
          <h1 className="font-display font-bold text-2xl text-white">Meeting History</h1>
          <p className="text-blue-400/50 text-sm font-body mt-0.5">Browse and review past meetings</p>
        </div>

        <div className="mb-6">
          <MeetingHistory meetings={meetings} onSelect={handleSelect} />
        </div>

        {selected && (
          <div className="animate-slide-up">
            <div className="flex items-center gap-3 mb-4">
              <h2 className="font-display font-bold text-lg text-white">{selected.title}</h2>
              <span className="keyword-tag">{new Date(selected.date).toLocaleDateString()}</span>
            </div>

            {loading ? (
              <div className="glass-card p-8 text-center">
                <div className="text-3xl mb-3 animate-spin">⚙️</div>
                <p className="text-blue-400/60 text-sm">Loading meeting details...</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
                  <LiveTranscript transcripts={detail?.transcripts || []} />
                  <div className="glass-card p-5">
                    <h3 className="font-display font-semibold text-white text-sm mb-3">🧠 AI Summary</h3>
                    <p className="text-sm text-blue-100/70 leading-relaxed font-body">
                      {detail?.insights?.summary || 'No summary available.'}
                    </p>
                    {detail?.insights?.keywords?.length > 0 && (
                      <div className="mt-4">
                        <p className="text-xs text-blue-400/40 font-mono uppercase tracking-wider mb-2">Keywords</p>
                        <div className="flex flex-wrap">
                          {detail.insights.keywords.map((k, i) => (
                            <span key={i} className="keyword-tag">{k}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <ActionItems
                  items={detail?.insights?.action_items || []}
                  keyPoints={detail?.insights?.key_points || []}
                />
              </>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
