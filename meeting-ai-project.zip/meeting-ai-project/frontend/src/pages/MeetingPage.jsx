// MeetingPage.jsx - Live meeting recorder + dashboard
import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import LiveTranscript from '../components/LiveTranscript';
import InsightsPanel from '../components/InsightsPanel';
import ActionItems from '../components/ActionItems';
import { SpeakerPieChart } from '../components/SpeakerChart';
import { startMeeting, stopMeeting, addTranscript, createWebSocket, MOCK_INSIGHTS } from '../api';

// Demo sentences for mock STT when Whisper is offline
const DEMO_SENTENCES = [
  { speaker: 'Alex', text: 'Good morning everyone. Lets get started with the agenda for today.' },
  { speaker: 'Sarah', text: 'I think we should prioritize the AI features based on the latest customer feedback.' },
  { speaker: 'Alex', text: 'Agreed. The machine learning pipeline needs significant improvements this sprint.' },
  { speaker: 'Mike', text: 'We also need to allocate budget for cloud infrastructure scaling.' },
  { speaker: 'Sarah', text: 'The sprint velocity has been excellent. We completed 18 out of 20 story points.' },
  { speaker: 'Alex', text: 'Let us schedule a follow-up meeting to review the action items by Friday.' },
  { speaker: 'Mike', text: 'I will create the detailed specification document for the AI feature set.' },
  { speaker: 'Sarah', text: 'The customer onboarding experience needs to be improved before the Q4 launch.' },
];

export default function MeetingPage() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState('idle'); // idle | running | stopped
  const [meetingId, setMeetingId] = useState(null);
  const [title, setTitle] = useState('');
  const [transcripts, setTranscripts] = useState([]);
  const [insights, setInsights] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [wsConnected, setWsConnected] = useState(false);
  const [demoIndex, setDemoIndex] = useState(0);

  const timerRef = useRef(null);
  const wsRef = useRef(null);
  const demoIntervalRef = useRef(null);
  const startTimeRef = useRef(null);

  // Timer
  useEffect(() => {
    if (phase === 'running') {
      startTimeRef.current = Date.now() - elapsed * 1000;
      timerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - startTimeRef.current) / 1000));
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [phase]);

  const formatElapsed = (s) => {
    const h = Math.floor(s / 3600).toString().padStart(2, '0');
    const m = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    return `${h}:${m}:${sec}`;
  };

  const handleStart = async () => {
    const meetingTitle = title.trim() || `Meeting — ${new Date().toLocaleDateString()}`;
    try {
      const res = await startMeeting(meetingTitle);
      const mid = res.meeting_id;
      setMeetingId(mid);
      setPhase('running');
      setTranscripts([]);
      setInsights(null);
      setElapsed(0);

      // WebSocket
      wsRef.current = createWebSocket(mid, {
        onConnected: () => setWsConnected(true),
        onClose: () => setWsConnected(false),
        onTranscript: (data) => setTranscripts((p) => [...p, data]),
        onInsights: (data) => setInsights(data),
      });

      // Demo auto-transcript simulation
      let idx = 0;
      demoIntervalRef.current = setInterval(async () => {
        if (idx >= DEMO_SENTENCES.length) {
          idx = 0;
        }
        const line = DEMO_SENTENCES[idx++];
        setDemoIndex(idx);
        try {
          const tRes = await addTranscript(mid, line.speaker, line.text, 0.9 + Math.random() * 0.1);
          setTranscripts((p) => [
            ...p,
            { transcript_id: tRes.transcript_id || Date.now(), speaker: line.speaker, text: line.text, timestamp: new Date().toISOString(), confidence: 0.95 },
          ]);
        } catch {
          setTranscripts((p) => [
            ...p,
            { transcript_id: Date.now(), speaker: line.speaker, text: line.text, timestamp: new Date().toISOString(), confidence: 0.95 },
          ]);
        }
      }, 4000);

    } catch (err) {
      // Offline demo mode
      const mockId = Date.now();
      setMeetingId(mockId);
      setPhase('running');
      setTranscripts([]);
      setInsights(null);
      setElapsed(0);

      let idx = 0;
      demoIntervalRef.current = setInterval(() => {
        if (idx >= DEMO_SENTENCES.length) idx = 0;
        const line = DEMO_SENTENCES[idx++];
        setTranscripts((p) => [
          ...p,
          { transcript_id: Date.now(), speaker: line.speaker, text: line.text, timestamp: new Date().toISOString(), confidence: 0.95 },
        ]);
        // Mock insights after 3 entries
        if (idx >= 3) setInsights(MOCK_INSIGHTS);
      }, 4000);
    }
  };

  const handleStop = async () => {
    clearInterval(demoIntervalRef.current);
    wsRef.current?.close();
    setPhase('stopped');
    try {
      await stopMeeting(meetingId, elapsed);
    } catch {}
  };

  return (
    <div className="flex min-h-screen hero-bg noise-overlay">
      <div className="absolute inset-0 grid-pattern opacity-20 pointer-events-none" />
      <Sidebar isMeetingActive={phase === 'running'} />

      <main className="flex-1 p-6 overflow-y-auto relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display font-bold text-2xl text-white">
              {phase === 'idle' ? 'Start New Meeting' : phase === 'running' ? 'Meeting in Progress' : 'Meeting Ended'}
            </h1>
            <p className="text-blue-400/50 text-sm font-body mt-0.5">
              {phase === 'idle' ? 'Configure and begin your AI-powered meeting' :
               phase === 'running' ? 'Recording and transcribing in real time...' :
               'Review your meeting insights below'}
            </p>
          </div>
          {phase === 'running' && (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-black/30 border border-red-500/20">
                <div className="record-dot" />
                <span className="font-mono text-white text-sm font-bold">{formatElapsed(elapsed)}</span>
              </div>
              <div className={`px-3 py-1.5 rounded-full text-xs font-display font-semibold border ${
                wsConnected ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-blue-500/10 border-blue-500/20 text-blue-400'
              }`}>
                {wsConnected ? '● WS Live' : '● Demo Mode'}
              </div>
            </div>
          )}
        </div>

        {/* Start panel */}
        {phase === 'idle' && (
          <div className="max-w-xl mx-auto mt-12">
            <div className="glass-card p-8 text-center">
              <div className="text-6xl mb-6 animate-float">🎙️</div>
              <h2 className="font-display font-bold text-2xl text-white mb-2">Ready to Record</h2>
              <p className="text-blue-300/60 text-sm mb-6 font-body">
                Enter a meeting title and click Start. Audio will be processed by Whisper AI for real-time transcription.
              </p>
              <input
                type="text"
                placeholder="Meeting title (optional)..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-blue-400/30 font-body text-sm mb-5 focus:outline-none focus:border-blue-500/40"
                onKeyDown={(e) => e.key === 'Enter' && handleStart()}
              />
              <button onClick={handleStart} className="w-full py-4 rounded-xl glow-btn text-white text-base">
                🎙️ Start Meeting
              </button>
              <p className="text-xs text-blue-400/30 mt-4 font-mono">
                Demo mode will simulate speech if backend is offline
              </p>
            </div>
          </div>
        )}

        {/* Active / stopped meeting */}
        {phase !== 'idle' && (
          <>
            {/* Controls */}
            {phase === 'running' && (
              <div className="flex gap-3 mb-5">
                <button onClick={handleStop} className="px-6 py-3 rounded-xl danger-btn text-white">
                  ⏹ Stop Meeting
                </button>
                <button onClick={() => navigate('/dashboard')} className="px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm font-display font-semibold hover:bg-white/10 transition-all">
                  📊 Dashboard
                </button>
              </div>
            )}
            {phase === 'stopped' && (
              <div className="flex gap-3 mb-5">
                <button onClick={() => { setPhase('idle'); setTitle(''); setTranscripts([]); setInsights(null); setElapsed(0); }}
                  className="px-6 py-3 rounded-xl glow-btn text-white">
                  🎙️ New Meeting
                </button>
                <button onClick={() => navigate('/dashboard')} className="px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm font-display font-semibold hover:bg-white/10 transition-all">
                  📊 View Dashboard
                </button>
              </div>
            )}

            {/* Main grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              <LiveTranscript transcripts={transcripts} isLive={phase === 'running'} />
              <InsightsPanel insights={insights} />
            </div>

            <div className="mb-4">
              <ActionItems
                items={insights?.action_items || []}
                keyPoints={insights?.key_points || []}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <SpeakerPieChart transcripts={transcripts} />
              <div className="glass-card p-5">
                <h3 className="font-display font-semibold text-white text-sm flex items-center gap-2 mb-4">
                  <span>📊</span> Meeting Summary
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-sm text-blue-300/60">Duration</span>
                    <span className="font-mono text-white text-sm">{formatElapsed(elapsed)}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-sm text-blue-300/60">Transcript segments</span>
                    <span className="font-mono text-white text-sm">{transcripts.length}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-sm text-blue-300/60">Action items</span>
                    <span className="font-mono text-white text-sm">{insights?.action_items?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <span className="text-sm text-blue-300/60">Sentiment</span>
                    <span className={`text-sm font-display font-semibold ${
                      insights?.sentiment === 'positive' ? 'text-emerald-400' :
                      insights?.sentiment === 'negative' ? 'text-red-400' : 'text-blue-400'
                    }`}>{insights?.sentiment || '—'}</span>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
