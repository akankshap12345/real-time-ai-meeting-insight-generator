// DashboardPage.jsx
import { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import StatsCards from '../components/StatsCards';
import LiveTranscript from '../components/LiveTranscript';
import InsightsPanel from '../components/InsightsPanel';
import ActionItems from '../components/ActionItems';
import { SpeakerPieChart, TimelineChart } from '../components/SpeakerChart';
import MeetingHistory from '../components/MeetingHistory';
import {
  getMeetingHistory, getMeeting, createWebSocket,
  MOCK_HISTORY, MOCK_TRANSCRIPTS, MOCK_INSIGHTS
} from '../api';

export default function DashboardPage() {
  const [meetings, setMeetings] = useState(MOCK_HISTORY);
  const [selectedMeeting, setSelectedMeeting] = useState(null);
  const [transcripts, setTranscripts] = useState(MOCK_TRANSCRIPTS);
  const [insights, setInsights] = useState(MOCK_INSIGHTS);
  const [wsConnected, setWsConnected] = useState(false);

  useEffect(() => {
    getMeetingHistory()
      .then((res) => setMeetings(res.meetings || MOCK_HISTORY))
      .catch(() => setMeetings(MOCK_HISTORY));

    // Global WS connection
    const ws = createWebSocket(null, {
      onConnected: () => setWsConnected(true),
      onClose: () => setWsConnected(false),
      onTranscript: (data) => setTranscripts((prev) => [...prev, data]),
      onInsights: (data) => setInsights(data),
    });
    return () => ws.close();
  }, []);

  const handleSelectMeeting = async (meeting) => {
    setSelectedMeeting(meeting);
    try {
      const res = await getMeeting(meeting.meeting_id);
      if (res.transcripts) setTranscripts(res.transcripts);
      if (res.insights) setInsights(res.insights);
    } catch {
      setTranscripts(MOCK_TRANSCRIPTS);
      setInsights(MOCK_INSIGHTS);
    }
  };

  return (
    <div className="flex min-h-screen hero-bg noise-overlay">
      <div className="absolute inset-0 grid-pattern opacity-20 pointer-events-none" />

      <Sidebar />

      <main className="flex-1 p-6 overflow-y-auto relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display font-bold text-2xl text-white">
              {selectedMeeting ? selectedMeeting.title : 'Overview Dashboard'}
            </h1>
            <p className="text-blue-400/50 text-sm font-body mt-0.5">
              Real-time AI meeting insights
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-display font-semibold border ${
              wsConnected
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                : 'bg-blue-500/10 border-blue-500/20 text-blue-400'
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${wsConnected ? 'bg-emerald-400 animate-pulse' : 'bg-blue-400'}`} />
              {wsConnected ? 'WS Connected' : 'Demo Mode'}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <StatsCards />

        {/* Main 2-col grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <LiveTranscript transcripts={transcripts} isLive={false} />
          <InsightsPanel insights={insights} />
        </div>

        {/* Action items */}
        <div className="mb-4">
          <ActionItems
            items={insights?.action_items || []}
            keyPoints={insights?.key_points || []}
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <SpeakerPieChart transcripts={transcripts} />
          <TimelineChart transcripts={transcripts} />
        </div>

        {/* Meeting History */}
        <MeetingHistory meetings={meetings} onSelect={handleSelectMeeting} />
      </main>
    </div>
  );
}
