// LandingPage.jsx - Hero landing page
import { useNavigate } from 'react-router-dom';

const FEATURES = [
  { icon: '🎙️', title: 'Live Recording', desc: 'Browser-native audio capture with real-time streaming' },
  { icon: '⚡', title: 'Whisper AI STT', desc: 'OpenAI Whisper converts speech to text with 95%+ accuracy' },
  { icon: '🧠', title: 'NLP Insights', desc: 'T5/BART transformer models generate summaries & action items' },
  { icon: '📊', title: 'Live Dashboard', desc: 'WebSocket-powered real-time analytics and speaker charts' },
];

const STATS = [
  { label: 'Accuracy Rate', value: '95%+', sub: 'Whisper STT' },
  { label: 'Model Size', value: 'Base', sub: 'Whisper Model' },
  { label: 'Latency', value: '<2s', sub: 'Real-time updates' },
  { label: 'Storage', value: 'MySQL', sub: 'Persistent data' },
];

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen hero-bg noise-overlay relative overflow-hidden font-body">
      {/* Orbs */}
      <div className="orb w-96 h-96 bg-blue-600 top-[-100px] left-[-100px] opacity-20" />
      <div className="orb w-80 h-80 bg-cyan-500 top-[20%] right-[-80px] opacity-15" />
      <div className="orb w-64 h-64 bg-emerald-500 bottom-[10%] left-[30%] opacity-10" />

      {/* Grid pattern */}
      <div className="absolute inset-0 grid-pattern opacity-30" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-8 py-5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-lg shadow-lg">
            🧠
          </div>
          <span className="font-display font-bold text-lg text-white tracking-tight">MeetingAI</span>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => navigate('/dashboard')}
            className="px-4 py-2 text-sm text-blue-300 hover:text-white transition-colors font-display font-medium"
          >
            Dashboard
          </button>
          <button
            onClick={() => navigate('/meeting')}
            className="px-5 py-2 rounded-xl glow-btn text-white text-sm"
          >
            Start Meeting →
          </button>
        </div>
      </nav>

      {/* Hero */}
      <div className="relative z-10 max-w-5xl mx-auto px-8 pt-20 pb-16 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 mb-8">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-sm text-blue-300 font-body font-medium tracking-wide">AI-Powered Meeting Intelligence</span>
        </div>

        <h1 className="font-display font-extrabold text-5xl md:text-7xl text-white leading-tight mb-6">
          Real-Time{' '}
          <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent">
            Meeting Insights
          </span>
          <br />
          Powered by AI
        </h1>

        <p className="text-lg md:text-xl text-blue-100/60 max-w-2xl mx-auto mb-10 leading-relaxed font-body">
          Record your meetings, get instant transcriptions via Whisper, and let our NLP models
          generate summaries, action items, and key insights — all in real time.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button
            onClick={() => navigate('/meeting')}
            className="px-8 py-4 rounded-2xl glow-btn text-white text-lg"
          >
            🎙️ Start a Meeting
          </button>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-8 py-4 rounded-2xl bg-white/5 border border-white/10 text-white text-lg font-display font-semibold hover:bg-white/10 transition-all"
          >
            📊 View Dashboard
          </button>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-20">
          {STATS.map((s) => (
            <div key={s.label} className="glass-card p-4 text-center">
              <div className="font-display font-bold text-2xl text-white mb-1">{s.value}</div>
              <div className="text-xs text-blue-300/70 font-body">{s.label}</div>
              <div className="text-xs text-blue-500/50 mt-0.5">{s.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="relative z-10 max-w-5xl mx-auto px-8 pb-20">
        <h2 className="font-display font-bold text-3xl text-center text-white mb-10">
          Everything you need for{' '}
          <span className="text-blue-400">smarter meetings</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURES.map((f) => (
            <div key={f.title} className="glass-card p-5">
              <div className="text-3xl mb-3">{f.icon}</div>
              <h3 className="font-display font-semibold text-white mb-2">{f.title}</h3>
              <p className="text-sm text-blue-200/50 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tech Stack */}
      <div className="relative z-10 max-w-5xl mx-auto px-8 pb-24">
        <div className="glass-card p-8 text-center">
          <p className="text-xs text-blue-400/50 font-mono mb-3 uppercase tracking-widest">Tech Stack</p>
          <div className="flex flex-wrap justify-center gap-3">
            {['React', 'FastAPI', 'Whisper AI', 'HuggingFace T5', 'MySQL', 'WebSockets', 'Tailwind CSS', 'Chart.js'].map((t) => (
              <span key={t} className="keyword-tag text-sm">{t}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 text-center pb-8">
        <p className="text-blue-400/30 text-sm font-body">
          Built with ❤️ — Student AI Project
        </p>
      </footer>
    </div>
  );
}
