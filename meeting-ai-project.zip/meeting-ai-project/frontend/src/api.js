// api.js - API Service Layer
const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';
const WS_URL = process.env.REACT_APP_WS_URL || 'ws://localhost:8000';

// ─── HTTP Helpers ──────────────────────────────────────────────────────────────
async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || 'Request failed');
  }
  return res.json();
}

const get = (path) => request(path);
const post = (path, body) => request(path, { method: 'POST', body: JSON.stringify(body) });

// ─── Meeting API ───────────────────────────────────────────────────────────────
export const startMeeting = (title, userId = 1) =>
  post('/start_meeting', { title, user_id: userId });

export const stopMeeting = (meetingId, duration) =>
  post('/stop_meeting', { meeting_id: meetingId, duration });

export const getMeetingHistory = (limit = 20) =>
  get(`/meeting_history?limit=${limit}`);

export const getMeeting = (meetingId) =>
  get(`/meeting/${meetingId}`);

// ─── Transcript API ────────────────────────────────────────────────────────────
export const addTranscript = (meetingId, speaker, text, confidence = 1.0) =>
  post('/add_transcript', { meeting_id: meetingId, speaker, text, confidence });

export const getTranscripts = (meetingId) =>
  get(`/transcripts/${meetingId}`);

// ─── Insights API ──────────────────────────────────────────────────────────────
export const getMeetingSummary = (meetingId) =>
  get(`/meeting_summary/${meetingId}`);

export const generateInsights = (meetingId) =>
  post(`/generate_insights/${meetingId}`, {});

// ─── Stats API ─────────────────────────────────────────────────────────────────
export const getDashboardStats = () => get('/stats');

// ─── WebSocket ─────────────────────────────────────────────────────────────────
export function createWebSocket(meetingId, handlers = {}) {
  const url = meetingId ? `${WS_URL}/ws/${meetingId}` : `${WS_URL}/ws`;
  const ws = new WebSocket(url);

  ws.onopen = () => {
    console.log(`WebSocket connected: ${url}`);
    handlers.onOpen?.();
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      switch (data.type) {
        case 'transcript':
          handlers.onTranscript?.(data.data);
          break;
        case 'insights':
          handlers.onInsights?.(data.data);
          break;
        case 'meeting_status':
          handlers.onStatus?.(data.status);
          break;
        case 'connected':
          handlers.onConnected?.(data);
          break;
        default:
          handlers.onMessage?.(data);
      }
    } catch (e) {
      console.error('WS parse error:', e);
    }
  };

  ws.onclose = () => {
    console.log('WebSocket disconnected');
    handlers.onClose?.();
  };

  ws.onerror = (err) => {
    console.error('WebSocket error:', err);
    handlers.onError?.(err);
  };

  return ws;
}

// ─── Demo / Mock Data for UI when backend is offline ──────────────────────────
export const MOCK_STATS = {
  total_meetings: 12,
  total_duration_seconds: 43200,
  total_transcripts: 847,
  total_insights: 12,
};

export const MOCK_HISTORY = [
  { meeting_id: 1, title: 'Q4 Product Roadmap Planning', date: '2025-03-01T10:00:00', duration: 3600, status: 'completed', participant_count: 5, summary: 'Discussed Q4 AI feature prioritization and ML pipeline improvements.' },
  { meeting_id: 2, title: 'Sprint Review - Week 12', date: '2025-03-05T14:00:00', duration: 1800, status: 'completed', participant_count: 4, summary: '18/20 story points completed. Strong sprint velocity.' },
  { meeting_id: 3, title: 'Stakeholder Sync - AI Features', date: '2025-03-07T11:00:00', duration: 2700, status: 'completed', participant_count: 6, summary: 'Aligned on AI feature roadmap and customer feedback priorities.' },
];

export const MOCK_TRANSCRIPTS = [
  { transcript_id: 1, speaker: 'Alex', text: 'Good morning everyone. Today we are going to discuss the Q4 product roadmap.', timestamp: '10:01:00', confidence: 0.95 },
  { transcript_id: 2, speaker: 'Sarah', text: 'I think we should prioritize the AI features in the next quarter based on customer feedback.', timestamp: '10:02:00', confidence: 0.92 },
  { transcript_id: 3, speaker: 'Alex', text: 'Agreed. The machine learning pipeline needs significant improvements as well.', timestamp: '10:03:00', confidence: 0.97 },
  { transcript_id: 4, speaker: 'Mike', text: 'We also need to allocate budget for cloud infrastructure scaling.', timestamp: '10:04:00', confidence: 0.89 },
];

export const MOCK_INSIGHTS = {
  summary: 'The team discussed Q4 product roadmap with focus on AI feature prioritization and ML pipeline improvements based on customer feedback. Budget allocation for cloud infrastructure was also addressed.',
  key_points: [
    'Prioritize AI features in Q4 based on customer demand',
    'ML pipeline requires significant architectural improvements',
    'Cloud infrastructure budget needs to be allocated',
    'Sprint velocity has been strong with 90% story point completion',
  ],
  action_items: [
    'Update ML pipeline architecture document by end of month',
    'Collect and analyze customer feedback survey results',
    'Create detailed AI feature specification document',
    'Schedule follow-up stakeholder meeting in 2 weeks',
    'Allocate Q4 cloud infrastructure budget',
  ],
  keywords: ['AI features', 'product roadmap', 'machine learning', 'customer feedback', 'sprint', 'infrastructure'],
  sentiment: 'positive',
};
