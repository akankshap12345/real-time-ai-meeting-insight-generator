# 🧠 Real-Time AI Meeting Insight Generator

A full-stack student AI project that records meeting audio, converts speech to text using **OpenAI Whisper**, analyzes conversations with **HuggingFace Transformers**, and displays live insights on a stunning modern dashboard.

---

## 📸 Features

| Feature | Technology |
|---|---|
| Real-time speech-to-text | OpenAI Whisper |
| Meeting summarization | HuggingFace BART/T5 |
| Action item extraction | NLP rule-based + transformers |
| Live transcript stream | WebSockets |
| Interactive dashboard | React + Tailwind CSS + Chart.js |
| Data persistence | MySQL |
| REST API | Python FastAPI |

---

## 🗂️ Project Structure

```
meeting-ai-project/
├── frontend/                  # React app
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Sidebar.jsx
│   │   │   ├── StatsCards.jsx
│   │   │   ├── LiveTranscript.jsx
│   │   │   ├── InsightsPanel.jsx
│   │   │   ├── ActionItems.jsx
│   │   │   ├── SpeakerChart.jsx
│   │   │   └── MeetingHistory.jsx
│   │   ├── pages/
│   │   │   ├── LandingPage.jsx
│   │   │   ├── DashboardPage.jsx
│   │   │   ├── MeetingPage.jsx
│   │   │   └── HistoryPage.jsx
│   │   ├── styles/
│   │   │   └── global.css
│   │   ├── api.js
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── tailwind.config.js
│
├── backend/
│   ├── main.py               # FastAPI app entry point
│   ├── routes.py             # API route handlers
│   ├── websocket.py          # WebSocket manager
│   ├── ai_models.py          # Whisper + NLP models
│   ├── database.py           # MySQL operations
│   ├── models.py             # Pydantic schemas
│   └── .env.example
│
├── database/
│   └── schema.sql            # MySQL schema + sample data
│
├── requirements.txt
└── README.md
```

---

## 🛠️ Prerequisites

- **Python** 3.10 or 3.11
- **Node.js** 18+ and npm
- **MySQL** 8.0+
- **ffmpeg** (required by Whisper for audio processing)

---

## ⚙️ Step-by-Step Setup & Run Guide

### Step 1 — Install ffmpeg

**Windows:**
```bash
# Using winget
winget install ffmpeg
# OR download from https://ffmpeg.org/download.html and add to PATH
```

**macOS:**
```bash
brew install ffmpeg
```

**Ubuntu/Linux:**
```bash
sudo apt update && sudo apt install ffmpeg -y
```

---

### Step 2 — Set Up MySQL Database

1. Open MySQL Workbench or MySQL CLI
2. Run the schema file:

```bash
mysql -u root -p < database/schema.sql
```

This creates the `meeting_ai_db` database with all tables and sample data.

---

### Step 3 — Set Up Python Backend

```bash
# Navigate to project root
cd meeting-ai-project

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

> **Note:** Installing PyTorch + Whisper may take a few minutes. It will download ~150MB.

---

### Step 4 — Configure Backend Environment

```bash
# Copy the example env file
cp backend/.env.example backend/.env

# Edit backend/.env and set your MySQL password:
# DB_PASSWORD=your_actual_password
```

---

### Step 5 — Start the Backend Server

```bash
cd backend
python main.py
```

You should see:
```
INFO: 🚀 Real-Time AI Meeting Insight Generator - Starting up
INFO: Uvicorn running on http://0.0.0.0:8000
```

**Verify it works:**
- Open http://localhost:8000 → should return `{"status": "ok"}`
- Open http://localhost:8000/docs → Swagger API documentation

---

### Step 6 — Set Up React Frontend

```bash
# Open a new terminal
cd meeting-ai-project/frontend

# Install dependencies
npm install
```

---

### Step 7 — Start the Frontend

```bash
npm start
```

Opens automatically at **http://localhost:3000**

---

## 🎮 How to Use

1. **Landing Page** → Click "Start Meeting" or "View Dashboard"
2. **Start Meeting Page** → Enter a title and click "🎙️ Start Meeting"
3. The system will:
   - Send audio to Whisper for transcription
   - Display live transcript in real time
   - Generate AI insights (summary, action items, keywords)
   - Push updates via WebSocket
4. Click "⏹ Stop Meeting" to end
5. View history at `/history`

> **Demo Mode:** If the backend is offline, the frontend automatically uses mock data and simulates transcript generation every 4 seconds.

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/start_meeting` | Start a new meeting |
| POST | `/api/stop_meeting` | End meeting + trigger insights |
| GET | `/api/meeting_history` | List all meetings |
| GET | `/api/meeting/{id}` | Get meeting details |
| POST | `/api/add_transcript` | Add transcript segment |
| GET | `/api/transcripts/{id}` | Get meeting transcripts |
| GET | `/api/meeting_summary/{id}` | Get AI insights |
| GET | `/api/stats` | Dashboard statistics |
| WS | `/ws/{meeting_id}` | WebSocket for meeting room |
| WS | `/ws` | Global dashboard WebSocket |

---

## 🗄️ Database Schema

```sql
users          (id, name, email, created_at)
meetings       (meeting_id, user_id, title, date, duration, status)
transcripts    (transcript_id, meeting_id, speaker, text, timestamp, confidence)
insights       (insight_id, meeting_id, summary, key_points, action_items, keywords, sentiment)
```

---

## 🔧 Customization

### Change Whisper Model Size

Edit `backend/.env`:
```
WHISPER_MODEL=small   # tiny | base | small | medium | large
```

| Model | Size | Speed | Accuracy |
|---|---|---|---|
| tiny | 39MB | Fastest | Good |
| base | 74MB | Fast | Better ✅ |
| small | 244MB | Medium | Great |
| medium | 769MB | Slow | Excellent |

### Use a Different Summarization Model

Edit `backend/ai_models.py` → change `model=` in `load_summarizer()`:
- `facebook/bart-large-cnn` (default, best quality)
- `t5-small` (faster, smaller)
- `sshleifer/distilbart-cnn-6-6` (distilled, fast)

---

## ⚠️ Troubleshooting

**MySQL connection error:**
- Verify MySQL is running: `mysql --version`
- Check credentials in `backend/.env`

**Whisper not found:**
```bash
pip install openai-whisper
```

**PyTorch installation issues:**
```bash
pip install torch --index-url https://download.pytorch.org/whl/cpu
```

**Frontend proxy error:**
- Ensure backend is running on port 8000
- Check `"proxy": "http://localhost:8000"` in `frontend/package.json`

---

## 👩‍💻 Built With

- React 18 + React Router
- Tailwind CSS (utility-first styling)
- Chart.js + react-chartjs-2
- FastAPI + Uvicorn
- OpenAI Whisper
- HuggingFace Transformers (BART)
- MySQL + mysql-connector-python
- WebSockets (native)

---

*Student AI Project — Real-Time Meeting Insight Generator*
