"""
main.py - FastAPI Application Entry Point
Real-Time AI Meeting Insight Generator
"""

import logging
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from routes import router
from websocket import manager

# ─── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
logger = logging.getLogger(__name__)


# ─── Startup / Shutdown ──────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 Real-Time AI Meeting Insight Generator - Starting up")
    logger.info("📡 WebSocket server ready")
    logger.info("🤖 AI models will load on first use")
    yield
    logger.info("👋 Shutting down")


# ─── App ─────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Real-Time AI Meeting Insight Generator",
    description="Records meeting audio, converts speech to text, and generates AI insights.",
    version="1.0.0",
    lifespan=lifespan,
)

# ─── CORS ────────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routes ──────────────────────────────────────────────────────────────────────
app.include_router(router, prefix="/api")


# ─── WebSocket ───────────────────────────────────────────────────────────────────
@app.websocket("/ws/{meeting_id}")
async def websocket_meeting(websocket: WebSocket, meeting_id: str):
    """WebSocket endpoint for a specific meeting room."""
    await manager.connect(websocket, meeting_id)
    await websocket.send_json({
        "type": "connected",
        "meeting_id": meeting_id,
        "message": f"Connected to meeting room {meeting_id}"
    })
    try:
        while True:
            data = await websocket.receive_text()
            # Echo back any received messages (for debugging)
            await websocket.send_json({"type": "ack", "data": data})
    except WebSocketDisconnect:
        manager.disconnect(websocket, meeting_id)


@app.websocket("/ws")
async def websocket_global(websocket: WebSocket):
    """Global WebSocket for dashboard-wide updates."""
    await manager.connect(websocket, "global")
    await websocket.send_json({
        "type": "connected",
        "message": "Connected to global update channel"
    })
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, "global")


# ─── Health Check ────────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {
        "status": "ok",
        "service": "Real-Time AI Meeting Insight Generator",
        "version": "1.0.0",
        "docs": "/docs"
    }


@app.get("/health")
async def health():
    return {"status": "healthy"}


# ─── Run ─────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True, log_level="info")
