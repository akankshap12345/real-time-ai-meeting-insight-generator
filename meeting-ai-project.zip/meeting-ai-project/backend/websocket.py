"""
websocket.py - WebSocket Manager for Real-Time Updates
Real-Time AI Meeting Insight Generator
"""

import json
import logging
from typing import Dict, List
from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages WebSocket connections per meeting room."""

    def __init__(self):
        # meeting_id -> list of websockets
        self.active_connections: Dict[str, List[WebSocket]] = {}
        # Global broadcast connections (dashboard viewers)
        self.global_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket, meeting_id: str = "global"):
        await websocket.accept()
        if meeting_id == "global":
            self.global_connections.append(websocket)
        else:
            if meeting_id not in self.active_connections:
                self.active_connections[meeting_id] = []
            self.active_connections[meeting_id].append(websocket)
        logger.info(f"WebSocket connected: meeting={meeting_id}")

    def disconnect(self, websocket: WebSocket, meeting_id: str = "global"):
        if meeting_id == "global":
            if websocket in self.global_connections:
                self.global_connections.remove(websocket)
        else:
            if meeting_id in self.active_connections:
                connections = self.active_connections[meeting_id]
                if websocket in connections:
                    connections.remove(websocket)
                if not connections:
                    del self.active_connections[meeting_id]
        logger.info(f"WebSocket disconnected: meeting={meeting_id}")

    async def send_to_meeting(self, meeting_id: str, data: dict):
        """Send message to all clients in a specific meeting room."""
        connections = self.active_connections.get(meeting_id, [])
        disconnected = []
        for ws in connections:
            try:
                await ws.send_json(data)
            except Exception:
                disconnected.append(ws)
        for ws in disconnected:
            connections.remove(ws)

    async def broadcast(self, data: dict):
        """Broadcast to all global connections."""
        disconnected = []
        for ws in self.global_connections:
            try:
                await ws.send_json(data)
            except Exception:
                disconnected.append(ws)
        for ws in disconnected:
            self.global_connections.remove(ws)

    async def send_transcript_update(self, meeting_id: str, transcript: dict):
        """Send real-time transcript update."""
        message = {
            "type": "transcript",
            "meeting_id": meeting_id,
            "data": transcript
        }
        await self.send_to_meeting(meeting_id, message)
        await self.broadcast(message)

    async def send_insight_update(self, meeting_id: str, insights: dict):
        """Send real-time insight update."""
        message = {
            "type": "insights",
            "meeting_id": meeting_id,
            "data": insights
        }
        await self.send_to_meeting(meeting_id, message)
        await self.broadcast(message)

    async def send_meeting_status(self, meeting_id: str, status: str):
        """Send meeting status change."""
        message = {
            "type": "meeting_status",
            "meeting_id": meeting_id,
            "status": status
        }
        await self.send_to_meeting(meeting_id, message)
        await self.broadcast(message)


# Singleton instance
manager = ConnectionManager()
