"""
database.py - MySQL Database Connection & Operations
Real-Time AI Meeting Insight Generator
"""

import mysql.connector
from mysql.connector import pooling
import json
import os
from datetime import datetime
from typing import Optional, List, Dict, Any

# ─── Database Configuration ────────────────────────────────────────────────────
DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", 3306)),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "password"),
    "database": os.getenv("DB_NAME", "meeting_ai_db"),
    "autocommit": True,
}

# Connection pool
_pool = None


def get_pool():
    global _pool
    if _pool is None:
        _pool = pooling.MySQLConnectionPool(
            pool_name="meeting_ai_pool",
            pool_size=5,
            **DB_CONFIG
        )
    return _pool


def get_connection():
    """Get a connection from the pool."""
    return get_pool().get_connection()


# ─── Meeting Operations ─────────────────────────────────────────────────────────
def create_meeting(title: str, user_id: int = 1) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO meetings (user_id, title, status) VALUES (%s, %s, 'active')",
        (user_id, title)
    )
    meeting_id = cursor.lastrowid
    cursor.close()
    conn.close()
    return meeting_id


def stop_meeting(meeting_id: int, duration: int) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE meetings SET status='completed', duration=%s WHERE meeting_id=%s",
        (duration, meeting_id)
    )
    cursor.close()
    conn.close()
    return True


def get_meeting_history(limit: int = 20) -> List[Dict]:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT m.meeting_id, m.title, m.date, m.duration, m.status, m.participant_count,
               i.summary
        FROM meetings m
        LEFT JOIN insights i ON m.meeting_id = i.meeting_id
        ORDER BY m.date DESC
        LIMIT %s
    """, (limit,))
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    for row in rows:
        if isinstance(row.get("date"), datetime):
            row["date"] = row["date"].isoformat()
    return rows


def get_meeting_by_id(meeting_id: int) -> Optional[Dict]:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM meetings WHERE meeting_id=%s", (meeting_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row and isinstance(row.get("date"), datetime):
        row["date"] = row["date"].isoformat()
    return row


# ─── Transcript Operations ──────────────────────────────────────────────────────
def save_transcript(meeting_id: int, speaker: str, text: str, confidence: float = 1.0) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO transcripts (meeting_id, speaker, text, confidence) VALUES (%s, %s, %s, %s)",
        (meeting_id, speaker, text, confidence)
    )
    tid = cursor.lastrowid
    cursor.close()
    conn.close()
    return tid


def get_transcripts(meeting_id: int) -> List[Dict]:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        "SELECT * FROM transcripts WHERE meeting_id=%s ORDER BY timestamp ASC",
        (meeting_id,)
    )
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    for row in rows:
        if isinstance(row.get("timestamp"), datetime):
            row["timestamp"] = row["timestamp"].isoformat()
    return rows


# ─── Insights Operations ────────────────────────────────────────────────────────
def save_insight(meeting_id: int, summary: str, key_points: List[str],
                 action_items: List[str], keywords: List[str], sentiment: str = "neutral") -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO insights (meeting_id, summary, key_points, action_items, keywords, sentiment)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            summary=VALUES(summary),
            key_points=VALUES(key_points),
            action_items=VALUES(action_items),
            keywords=VALUES(keywords),
            sentiment=VALUES(sentiment),
            generated_at=CURRENT_TIMESTAMP
    """, (
        meeting_id,
        summary,
        json.dumps(key_points),
        json.dumps(action_items),
        json.dumps(keywords),
        sentiment
    ))
    iid = cursor.lastrowid
    cursor.close()
    conn.close()
    return iid


def get_insight(meeting_id: int) -> Optional[Dict]:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM insights WHERE meeting_id=%s ORDER BY generated_at DESC LIMIT 1", (meeting_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        for field in ["key_points", "action_items", "keywords"]:
            if isinstance(row.get(field), str):
                try:
                    row[field] = json.loads(row[field])
                except Exception:
                    row[field] = []
        if isinstance(row.get("generated_at"), datetime):
            row["generated_at"] = row["generated_at"].isoformat()
    return row


# ─── Stats ──────────────────────────────────────────────────────────────────────
def get_dashboard_stats() -> Dict:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT COUNT(*) as total FROM meetings")
    total_meetings = cursor.fetchone()["total"]
    cursor.execute("SELECT COALESCE(SUM(duration),0) as total FROM meetings WHERE status='completed'")
    total_duration = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) as total FROM transcripts")
    total_transcripts = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) as total FROM insights")
    total_insights = cursor.fetchone()["total"]
    cursor.close()
    conn.close()
    return {
        "total_meetings": total_meetings,
        "total_duration_seconds": int(total_duration),
        "total_transcripts": total_transcripts,
        "total_insights": total_insights,
    }
