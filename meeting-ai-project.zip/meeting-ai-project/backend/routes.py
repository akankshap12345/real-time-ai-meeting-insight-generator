"""
routes.py - API Route Handlers
Real-Time AI Meeting Insight Generator
"""

import base64
import logging
from typing import List, Optional
from fastapi import APIRouter, HTTPException, BackgroundTasks

from models import (
    StartMeetingRequest, StopMeetingRequest, TranscriptEntry,
    MeetingResponse, InsightResponse, TranscriptResponse,
    DashboardStats, AudioChunk
)
import database as db
import ai_models as ai
from websocket import manager

logger = logging.getLogger(__name__)
router = APIRouter()


# ─── Meeting Endpoints ──────────────────────────────────────────────────────────

@router.post("/start_meeting")
async def start_meeting(request: StartMeetingRequest):
    """Start a new meeting session."""
    try:
        meeting_id = db.create_meeting(request.title, request.user_id)
        await manager.send_meeting_status(str(meeting_id), "started")
        return {
            "success": True,
            "meeting_id": meeting_id,
            "title": request.title,
            "message": f"Meeting '{request.title}' started successfully"
        }
    except Exception as e:
        logger.error(f"Start meeting error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop_meeting")
async def stop_meeting(request: StopMeetingRequest, background_tasks: BackgroundTasks):
    """Stop a meeting and trigger final insight generation."""
    try:
        db.stop_meeting(request.meeting_id, request.duration)
        background_tasks.add_task(_generate_and_save_insights, request.meeting_id)
        await manager.send_meeting_status(str(request.meeting_id), "completed")
        return {
            "success": True,
            "meeting_id": request.meeting_id,
            "message": "Meeting stopped. Generating final insights..."
        }
    except Exception as e:
        logger.error(f"Stop meeting error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/meeting_history")
async def meeting_history(limit: int = 20):
    """Retrieve meeting history."""
    try:
        meetings = db.get_meeting_history(limit)
        return {"success": True, "meetings": meetings}
    except Exception as e:
        logger.error(f"Meeting history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/meeting/{meeting_id}")
async def get_meeting(meeting_id: int):
    """Get a specific meeting with its transcripts and insights."""
    try:
        meeting = db.get_meeting_by_id(meeting_id)
        if not meeting:
            raise HTTPException(status_code=404, detail="Meeting not found")
        transcripts = db.get_transcripts(meeting_id)
        insight = db.get_insight(meeting_id)
        return {
            "success": True,
            "meeting": meeting,
            "transcripts": transcripts,
            "insights": insight
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Transcript Endpoints ────────────────────────────────────────────────────────

@router.post("/add_transcript")
async def add_transcript(entry: TranscriptEntry, background_tasks: BackgroundTasks):
    """Add a transcript segment and trigger insight update."""
    try:
        tid = db.save_transcript(entry.meeting_id, entry.speaker, entry.text, entry.confidence)
        transcript_data = {
            "transcript_id": tid,
            "meeting_id": entry.meeting_id,
            "speaker": entry.speaker,
            "text": entry.text,
            "confidence": entry.confidence,
        }
        await manager.send_transcript_update(str(entry.meeting_id), transcript_data)

        # Periodically regenerate insights
        background_tasks.add_task(_generate_and_save_insights, entry.meeting_id)

        return {"success": True, "transcript_id": tid}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/transcribe_audio")
async def transcribe_audio_chunk(chunk: AudioChunk, background_tasks: BackgroundTasks):
    """Receive base64 audio, transcribe it, save transcript."""
    try:
        audio_bytes = base64.b64decode(chunk.audio_base64)
        text, confidence = ai.transcribe_audio(audio_bytes, chunk.sample_rate)
        if not text:
            return {"success": True, "text": "", "confidence": 0.0}

        tid = db.save_transcript(chunk.meeting_id, "Speaker", text, confidence)
        transcript_data = {
            "transcript_id": tid,
            "meeting_id": chunk.meeting_id,
            "speaker": "Speaker",
            "text": text,
            "confidence": confidence,
        }
        await manager.send_transcript_update(str(chunk.meeting_id), transcript_data)
        background_tasks.add_task(_generate_and_save_insights, chunk.meeting_id)
        return {"success": True, "text": text, "confidence": confidence, "transcript_id": tid}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/transcripts/{meeting_id}")
async def get_transcripts(meeting_id: int):
    try:
        transcripts = db.get_transcripts(meeting_id)
        return {"success": True, "transcripts": transcripts}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Insights Endpoints ──────────────────────────────────────────────────────────

@router.get("/meeting_summary/{meeting_id}")
async def meeting_summary(meeting_id: int):
    """Get the latest AI-generated insights for a meeting."""
    try:
        insight = db.get_insight(meeting_id)
        if not insight:
            # Generate on the fly
            transcripts = db.get_transcripts(meeting_id)
            full_text = " ".join([t["text"] for t in transcripts])
            if not full_text:
                return {"success": True, "insights": None, "message": "No transcript data yet"}
            insights = ai.generate_full_insights(full_text)
            iid = db.save_insight(meeting_id, **insights)
            insights["insight_id"] = iid
            insights["meeting_id"] = meeting_id
            return {"success": True, "insights": insights}
        return {"success": True, "insights": insight}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate_insights/{meeting_id}")
async def trigger_insights(meeting_id: int, background_tasks: BackgroundTasks):
    """Manually trigger insight generation for a meeting."""
    background_tasks.add_task(_generate_and_save_insights, meeting_id)
    return {"success": True, "message": "Insight generation triggered"}


# ─── Dashboard Stats ─────────────────────────────────────────────────────────────

@router.get("/stats")
async def dashboard_stats():
    try:
        stats = db.get_dashboard_stats()
        return {"success": True, "stats": stats}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Background Task ─────────────────────────────────────────────────────────────

async def _generate_and_save_insights(meeting_id: int):
    """Background task: regenerate insights and push via WebSocket."""
    try:
        transcripts = db.get_transcripts(meeting_id)
        if not transcripts:
            return
        full_text = " ".join([t["text"] for t in transcripts])
        if len(full_text.strip()) < 30:
            return

        insights = ai.generate_full_insights(full_text)
        db.save_insight(meeting_id, **insights)
        insights["meeting_id"] = meeting_id
        await manager.send_insight_update(str(meeting_id), insights)
        logger.info(f"Insights updated for meeting {meeting_id}")
    except Exception as e:
        logger.error(f"Background insight error for meeting {meeting_id}: {e}")
