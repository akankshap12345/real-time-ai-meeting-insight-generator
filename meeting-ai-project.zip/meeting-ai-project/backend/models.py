"""
models.py - Pydantic Data Models
Real-Time AI Meeting Insight Generator
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class StartMeetingRequest(BaseModel):
    title: str = Field(default="New Meeting", description="Meeting title")
    user_id: int = Field(default=1)


class StopMeetingRequest(BaseModel):
    meeting_id: int
    duration: int = Field(description="Duration in seconds")


class TranscriptEntry(BaseModel):
    meeting_id: int
    speaker: str = "Speaker"
    text: str
    confidence: float = 1.0


class MeetingResponse(BaseModel):
    meeting_id: int
    title: str
    date: str
    duration: int
    status: str
    participant_count: int
    summary: Optional[str] = None


class InsightResponse(BaseModel):
    insight_id: Optional[int] = None
    meeting_id: int
    summary: str
    key_points: List[str] = []
    action_items: List[str] = []
    keywords: List[str] = []
    sentiment: str = "neutral"
    generated_at: Optional[str] = None


class TranscriptResponse(BaseModel):
    transcript_id: int
    meeting_id: int
    speaker: str
    text: str
    timestamp: str
    confidence: float


class DashboardStats(BaseModel):
    total_meetings: int
    total_duration_seconds: int
    total_transcripts: int
    total_insights: int


class AudioChunk(BaseModel):
    meeting_id: int
    audio_base64: str
    sample_rate: int = 16000
