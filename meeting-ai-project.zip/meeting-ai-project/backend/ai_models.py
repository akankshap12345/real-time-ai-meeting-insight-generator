"""
ai_models.py - AI Model Integration
Whisper (Speech-to-Text) + HuggingFace T5 (Summarization & NLP)
Real-Time AI Meeting Insight Generator
"""

import os
import re
import json
import logging
import tempfile
import numpy as np
from typing import Optional, Tuple, List, Dict

logger = logging.getLogger(__name__)

# ─── Lazy Model Loading ─────────────────────────────────────────────────────────
_whisper_model = None
_summarizer = None
_classifier = None


def load_whisper():
    global _whisper_model
    if _whisper_model is None:
        try:
            import whisper
            model_size = os.getenv("WHISPER_MODEL", "base")
            logger.info(f"Loading Whisper model: {model_size}")
            _whisper_model = whisper.load_model(model_size)
            logger.info("Whisper model loaded successfully")
        except ImportError:
            logger.warning("openai-whisper not installed. Using mock transcription.")
            _whisper_model = "mock"
    return _whisper_model


def load_summarizer():
    global _summarizer
    if _summarizer is None:
        try:
            from transformers import pipeline
            logger.info("Loading T5 summarization model...")
            _summarizer = pipeline(
                "summarization",
                model="facebook/bart-large-cnn",
                max_length=150,
                min_length=40,
                truncation=True
            )
            logger.info("Summarization model loaded")
        except Exception as e:
            logger.warning(f"Could not load summarizer: {e}. Using extractive fallback.")
            _summarizer = "mock"
    return _summarizer


# ─── Speech-to-Text ─────────────────────────────────────────────────────────────
def transcribe_audio(audio_data: bytes, sample_rate: int = 16000) -> Tuple[str, float]:
    """
    Transcribe audio bytes using OpenAI Whisper.
    Returns (transcript_text, confidence_score)
    """
    model = load_whisper()

    if model == "mock":
        return _mock_transcription(), 0.85

    try:
        # Write audio to temp file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            import wave, struct
            with wave.open(f.name, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sample_rate)
                wf.writeframes(audio_data)
            tmp_path = f.name

        result = model.transcribe(tmp_path, language="en", fp16=False)
        os.unlink(tmp_path)

        text = result.get("text", "").strip()
        confidence = _estimate_confidence(result)
        return text, confidence

    except Exception as e:
        logger.error(f"Transcription error: {e}")
        return "", 0.0


def transcribe_audio_file(file_path: str) -> Tuple[str, float]:
    """Transcribe from a file path directly."""
    model = load_whisper()
    if model == "mock":
        return _mock_transcription(), 0.85
    try:
        result = model.transcribe(file_path, language="en", fp16=False)
        return result.get("text", "").strip(), _estimate_confidence(result)
    except Exception as e:
        logger.error(f"File transcription error: {e}")
        return "", 0.0


def _estimate_confidence(result: dict) -> float:
    """Estimate confidence from Whisper segments."""
    segments = result.get("segments", [])
    if not segments:
        return 0.9
    avg_logprob = np.mean([s.get("avg_logprob", -0.5) for s in segments])
    confidence = min(1.0, max(0.0, 1.0 + avg_logprob))
    return round(confidence, 2)


def _mock_transcription() -> str:
    """Mock transcription for demo when Whisper is unavailable."""
    mocks = [
        "We should focus on improving the AI pipeline for better accuracy.",
        "The sprint goals have been met and the team performed exceptionally well.",
        "Let's schedule a follow-up meeting to review the action items.",
        "Customer feedback suggests we need to improve the onboarding experience.",
        "The machine learning model accuracy has improved by 15 percent this week.",
    ]
    import random
    return random.choice(mocks)


# ─── Summarization ──────────────────────────────────────────────────────────────
def generate_summary(transcript_text: str) -> str:
    """Generate a meeting summary using T5/BART model."""
    if not transcript_text or len(transcript_text.strip()) < 50:
        return "Insufficient transcript data for summary generation."

    summarizer = load_summarizer()

    if summarizer == "mock":
        return _extractive_summary(transcript_text)

    try:
        # Truncate if too long (model limit)
        max_input = 1024
        words = transcript_text.split()
        if len(words) > max_input:
            transcript_text = " ".join(words[:max_input])

        result = summarizer(transcript_text)
        return result[0]["summary_text"]
    except Exception as e:
        logger.error(f"Summarization error: {e}")
        return _extractive_summary(transcript_text)


def _extractive_summary(text: str) -> str:
    """Fallback extractive summarization."""
    sentences = [s.strip() for s in re.split(r'[.!?]', text) if len(s.strip()) > 20]
    if not sentences:
        return text[:300] + "..."
    # Pick top sentences by length (heuristic for information density)
    sentences.sort(key=len, reverse=True)
    top = sentences[:3]
    return ". ".join(top) + "."


# ─── Key Points Extraction ──────────────────────────────────────────────────────
def extract_key_points(transcript_text: str) -> List[str]:
    """Extract key discussion points from transcript."""
    if not transcript_text:
        return []

    sentences = [s.strip() for s in re.split(r'[.!?\n]', transcript_text) if len(s.strip()) > 15]
    
    # Score sentences based on keywords
    keywords = [
        "important", "key", "must", "should", "need", "priority", "goal",
        "objective", "decision", "agreed", "plan", "strategy", "focus",
        "issue", "problem", "solution", "improve", "increase", "decrease"
    ]

    scored = []
    for sent in sentences:
        score = sum(1 for kw in keywords if kw.lower() in sent.lower())
        scored.append((score, sent))

    scored.sort(reverse=True)
    top_points = [s for _, s in scored[:5] if s]
    
    # Fallback: return first N sentences
    if not top_points:
        top_points = sentences[:4]

    return [p.capitalize() for p in top_points if p]


# ─── Action Items Extraction ─────────────────────────────────────────────────────
def extract_action_items(transcript_text: str) -> List[str]:
    """Extract actionable items from transcript."""
    if not transcript_text:
        return []

    sentences = [s.strip() for s in re.split(r'[.!?\n]', transcript_text) if len(s.strip()) > 10]
    
    action_triggers = [
        r"\bwill\b", r"\bshould\b", r"\bneed to\b", r"\bhave to\b",
        r"\blet's\b", r"\blets\b", r"\bplease\b", r"\baction\b",
        r"\btodo\b", r"\bto-do\b", r"\bfollow up\b", r"\bschedule\b",
        r"\bassign\b", r"\bresponsible\b", r"\bby \w+ \d+\b",
        r"\bdeadline\b", r"\bdue\b", r"\bcreate\b", r"\bbuild\b", r"\bimplement\b"
    ]

    action_items = []
    for sent in sentences:
        for pattern in action_triggers:
            if re.search(pattern, sent, re.IGNORECASE):
                action_items.append(sent.capitalize())
                break

    return list(dict.fromkeys(action_items))[:6]  # deduplicate, max 6


# ─── Keyword Extraction ──────────────────────────────────────────────────────────
def extract_keywords(transcript_text: str) -> List[str]:
    """Extract topic keywords using TF-IDF-like approach."""
    if not transcript_text:
        return []

    # Common stopwords
    stopwords = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "is", "it", "this", "that", "are", "was",
        "we", "i", "you", "they", "he", "she", "our", "your", "their", "my",
        "have", "has", "had", "be", "been", "will", "would", "could", "should",
        "do", "did", "does", "so", "as", "if", "not", "no", "yes", "also",
        "just", "very", "really", "about", "going", "think", "know", "like"
    }

    words = re.findall(r'\b[a-zA-Z]{4,}\b', transcript_text.lower())
    word_freq: Dict[str, int] = {}
    for word in words:
        if word not in stopwords:
            word_freq[word] = word_freq.get(word, 0) + 1

    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    return [w for w, _ in sorted_words[:8]]


# ─── Sentiment Analysis ──────────────────────────────────────────────────────────
def analyze_sentiment(text: str) -> str:
    """Simple rule-based sentiment analysis."""
    if not text:
        return "neutral"

    positive_words = ["good", "great", "excellent", "success", "achieved", "progress",
                      "improve", "better", "positive", "well", "happy", "agree", "yes"]
    negative_words = ["problem", "issue", "fail", "difficult", "concern", "risk",
                      "delay", "bad", "wrong", "error", "bug", "stuck", "blocker"]

    text_lower = text.lower()
    pos_count = sum(1 for w in positive_words if w in text_lower)
    neg_count = sum(1 for w in negative_words if w in text_lower)

    if pos_count > neg_count + 1:
        return "positive"
    elif neg_count > pos_count + 1:
        return "negative"
    return "neutral"


# ─── Full Insight Generation ─────────────────────────────────────────────────────
def generate_full_insights(transcript_text: str) -> Dict:
    """Generate all insights from transcript text."""
    return {
        "summary": generate_summary(transcript_text),
        "key_points": extract_key_points(transcript_text),
        "action_items": extract_action_items(transcript_text),
        "keywords": extract_keywords(transcript_text),
        "sentiment": analyze_sentiment(transcript_text),
    }
