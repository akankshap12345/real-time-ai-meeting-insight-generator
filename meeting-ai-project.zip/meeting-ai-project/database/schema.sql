-- ============================================================
-- Real-Time AI Meeting Insight Generator - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS meeting_ai_db;
USE meeting_ai_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Meetings Table
CREATE TABLE IF NOT EXISTS meetings (
    meeting_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(255) NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    duration INT DEFAULT 0 COMMENT 'Duration in seconds',
    status ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
    participant_count INT DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Transcripts Table
CREATE TABLE IF NOT EXISTS transcripts (
    transcript_id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_id INT NOT NULL,
    speaker VARCHAR(100) DEFAULT 'Speaker',
    text TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confidence FLOAT DEFAULT 1.0,
    FOREIGN KEY (meeting_id) REFERENCES meetings(meeting_id) ON DELETE CASCADE
);

-- Insights Table
CREATE TABLE IF NOT EXISTS insights (
    insight_id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_id INT NOT NULL,
    summary TEXT,
    key_points JSON,
    action_items JSON,
    keywords JSON,
    sentiment VARCHAR(50) DEFAULT 'neutral',
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (meeting_id) REFERENCES meetings(meeting_id) ON DELETE CASCADE
);

-- ============================================================
-- Sample Data for Demo
-- ============================================================
INSERT INTO users (name, email) VALUES
('Alex Johnson', 'alex@example.com'),
('Sarah Chen', 'sarah@example.com');

INSERT INTO meetings (user_id, title, date, duration, status, participant_count) VALUES
(1, 'Q4 Product Roadmap Planning', '2025-03-01 10:00:00', 3600, 'completed', 5),
(1, 'Sprint Review - Week 12', '2025-03-05 14:00:00', 1800, 'completed', 4),
(1, 'Stakeholder Sync - AI Features', '2025-03-07 11:00:00', 2700, 'completed', 6);

INSERT INTO transcripts (meeting_id, speaker, text, timestamp) VALUES
(1, 'Alex', 'Good morning everyone. Today we are going to discuss the Q4 product roadmap.', '2025-03-01 10:01:00'),
(1, 'Sarah', 'I think we should prioritize the AI features in the next quarter based on customer feedback.', '2025-03-01 10:02:00'),
(1, 'Alex', 'Agreed. The machine learning pipeline needs significant improvements as well.', '2025-03-01 10:03:00'),
(2, 'Sarah', 'The sprint went well. We completed 18 out of 20 story points.', '2025-03-05 14:01:00'),
(2, 'Alex', 'Great progress! The remaining items will be carried over to next sprint.', '2025-03-05 14:02:00');

INSERT INTO insights (meeting_id, summary, key_points, action_items, keywords) VALUES
(1, 'The team discussed Q4 product roadmap with focus on AI feature prioritization and ML pipeline improvements based on customer feedback.',
'["Prioritize AI features in Q4", "ML pipeline needs improvement", "Customer feedback drives roadmap", "5 team members aligned on goals"]',
'["Update ML pipeline architecture by end of month", "Collect customer feedback survey", "Create detailed AI feature spec document", "Schedule follow-up in 2 weeks"]',
'["AI features", "product roadmap", "machine learning", "customer feedback", "Q4 planning"]'),
(2, 'Sprint review showed strong progress with 90% story point completion. Remaining items to be carried over.',
'["18/20 story points completed", "Strong sprint velocity maintained", "2 items carried to next sprint"]',
'["Carry over incomplete items to Sprint 13", "Update sprint board", "Send sprint summary to stakeholders"]',
'["sprint review", "story points", "velocity", "backlog"]');
